
import React, { useState, useEffect, useContext } from "react";
// react plugin used to create charts
import { Line } from "react-chartjs-2";
// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row,
  Col
} from "reactstrap";
// core components
import {
  dashboardECGChart
} from "variables/charts.js";

import { MqttContext } from "../App.js";


function Dashboard() {
  const [pulse, setPulse] = useState(68);
  const [temp, setTemp] = useState(98.0);
  const [sys, setSys] = useState(120);
  const [dia, setDia] = useState(80);
  const [oxy, setOxy] = useState(99);

  const mqttService = useContext(MqttContext);

  useEffect(() => {
    mqttService.registerSubscriber("patient1/pulse", (topic, message) => {
      var json = message.toString();
      var mqttData = JSON.parse(json);
      setPulse(mqttData.data);
    });

    mqttService.registerSubscriber("patient1/temp", (topic, message) => {
      var json = message.toString();
      var mqttData = JSON.parse(json);
      setTemp(mqttData.data);
    });

    mqttService.registerSubscriber("patient1/bp", (topic, message) => {
      var json = message.toString();
      var mqttData = JSON.parse(json);
      setSys(mqttData.data.sys);
      setDia(mqttData.data.dia);
    });

    mqttService.registerSubscriber("patient1/oxy", (topic, message) => {
      var json = message.toString();
      var mqttData = JSON.parse(json);
      setOxy(mqttData.data);
    });

    return function cleanUp() {
      mqttService.unregisterSubscriber("patient1/pulse");
      mqttService.unregisterSubscriber("patient1/temp");
      mqttService.unregisterSubscriber("patient1/bp");
      mqttService.unregisterSubscriber("patient1/oxy");
    }

  }, [mqttService]);

  return (
    <>

      <div className="content">
        <Row>
          <Col lg="3" md="6" sm="6">
            <Card className="card-stats">
              <CardBody>
                <Row>
                  <Col md="4" xs="5">
                    <div className="icon-big text-center icon-warning">
                      <i className="nc-icon nc-badge text-warning" />
                    </div>
                  </Col>
                  <Col md="8" xs="7">
                    <div className="numbers">
                      <p className="card-category">Heart Rate</p>
                      <CardTitle tag="p">{pulse} BPM</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
          <Col lg="3" md="6" sm="6">
            <Card className="card-stats">
              <CardBody>
                <Row>
                  <Col md="4" xs="5">
                    <div className="icon-big text-center icon-warning">
                      <i className="nc-icon nc-money-coins text-success" />
                    </div>
                  </Col>
                  <Col md="8" xs="7">
                    <div className="numbers">
                      <p className="card-category">Oxygen Saturation</p>
                      <CardTitle tag="p">{oxy}%</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
          <Col lg="3" md="6" sm="6">
            <Card className="card-stats">
              <CardBody>
                <Row>
                  <Col md="4" xs="5">
                    <div className="icon-big text-center icon-warning">
                      <i className="nc-icon nc-key-25 text-danger" />
                    </div>
                  </Col>
                  <Col md="8" xs="7">
                    <div className="numbers">
                      <p className="card-category">Body Temperature</p>
                      <CardTitle tag="p">{temp}F</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
          <Col lg="3" md="6" sm="6">
            <Card className="card-stats">
              <CardBody>
                <Row>
                  <Col md="4" xs="5">
                    <div className="icon-big text-center icon-warning">
                      <i className="nc-icon nc-favourite-28 text-primary" />
                    </div>
                  </Col>
                  <Col md="8" xs="7">
                    <div className="numbers">
                      <p className="card-category">Blood Pressure</p>
                      <CardTitle tag="p">{sys}/{dia}</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
        </Row>
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <CardTitle tag="h5">ECG</CardTitle>
                <p className="card-category">Real Time Monitoring</p>
              </CardHeader>
              <CardBody>
                <Line
                  data={dashboardECGChart.data}
                  options={dashboardECGChart.options}
                  width={400}
                  height={100}
                />
              </CardBody>
              <CardFooter>
                <hr />
                <div className="stats">
                  <i className="fa fa-history" /> Updated 3 minutes ago
                  </div>
              </CardFooter>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}


export default Dashboard;
