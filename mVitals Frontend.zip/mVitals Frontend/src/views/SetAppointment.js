
import React from "react";

// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
} from "reactstrap";

class SetAppointment extends React.Component {
  render() {
    return (
      <>
        <div className="content">
          <Row className="my-3 justify-content-center">
            <Col md="8">
              <Card className="card-user">
                <CardHeader>
                  <CardTitle tag="h5">Set Patient Appointment</CardTitle>
                </CardHeader>
                <CardBody>
                  <Form>
                    <Row className="my-3 justify-content-center">
                      <Col className="pl-1" md="6">
                        <FormGroup>
                          <label>Patient ID</label>
                          <Input
                            defaultValue="000"
                            placeholder="Patient ID"
                            type="number"
                          />
                        </FormGroup>
                      </Col>
                      <Col className="pr-1" md="6">
                        <FormGroup>
                          <label>Patient Name</label>
                          <Input
                            defaultValue=""
                            placeholder="Patient Name"
                            type="text"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col className="pl-1" md="12">
                        <FormGroup>
                          <label>Select Appointment Time</label>
                          <Input placeholder="" type="datetime-local" />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label>Special Notes</label>
                          <Input
                            defaultValue="Please Be on Time"
                            type="textarea"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <div className="update ml-auto mr-auto">
                        <Button
                          className="btn-round"
                          color="primary"
                          type="submit"
                        >
                          Update
                        </Button>
                      </div>
                    </Row>
                  </Form>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </>
    );
  }
}

export default SetAppointment;
