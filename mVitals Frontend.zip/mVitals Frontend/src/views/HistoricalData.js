
import React from "react";
// react plugin used to create charts
import { Line, Bar } from "react-chartjs-2";
// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Row,
  Col,
  FormGroup,
  Input
} from "reactstrap";
// core components
import {
  dashboardBPChart,
  dashboardECGChart,
  dashboardTempChart,
  dashboardHeartrateChart,
  dashboardOxygenChart
} from "variables/charts.js";


class HistoricalData extends React.Component {
  render() {
    return (
      <>
        <div className="content">
          <Row>
            <Col md='4'>
              <FormGroup>
                <label>Select Start Time</label>
                <Input placeholder="" type="datetime-local" />
              </FormGroup>
            </Col>
            <Col md='4'>
              <FormGroup>
                <label>Select End Time</label>
                <Input placeholder="" type="datetime-local" />
              </FormGroup>
            </Col>
          </Row>
          <Row>
            <Col md="12">
              <Card>
                <CardHeader>
                  <CardTitle tag="h5">Blood Pressure</CardTitle>
                </CardHeader>
                <CardBody>
                  <Bar
                    data={dashboardBPChart.data}
                    options={dashboardBPChart.options}
                    width={400}
                    height={100}
                  />
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col md="12">
              <Card>
                <CardHeader>
                  <CardTitle tag="h5">ECG</CardTitle>
                </CardHeader>
                <CardBody>
                  <Line
                    data={dashboardECGChart.data}
                    options={dashboardECGChart.options}
                    width={400}
                    height={100}
                  />
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col md="12">
              <Card>
                <CardHeader>
                  <CardTitle tag="h5">Temperature</CardTitle>
                </CardHeader>
                <CardBody>
                  <Line
                    data={dashboardTempChart.data}
                    options={dashboardTempChart.options}
                    width={400}
                    height={100}
                  />
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col md="12">
              <Card>
                <CardHeader>
                  <CardTitle tag="h5">Heart Rate</CardTitle>
                </CardHeader>
                <CardBody>
                  <Line
                    data={dashboardHeartrateChart.data}
                    options={dashboardHeartrateChart.options}
                    width={400}
                    height={100}
                  />
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col md="12">
              <Card>
                <CardHeader>
                  <CardTitle tag="h5">Oxygen Level</CardTitle>
                </CardHeader>
                <CardBody>
                  <Line
                    data={dashboardOxygenChart.data}
                    options={dashboardOxygenChart.options}
                    width={400}
                    height={100}
                  />
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </>
    );
  }
}

export default HistoricalData;
