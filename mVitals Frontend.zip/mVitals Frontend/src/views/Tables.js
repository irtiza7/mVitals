
import React from "react";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
} from "reactstrap";


let patients = [
  {
    "name": "Rida Irfan",
    "userno": "01",
    "age": 47,
    "phone": "0300583293",
    "address": "Iqbal Town,Lahore",
  },
  {
    "name": "Yasir Ali",
    "userno": "02",
    "age": 34,
    "phone": "0302354532",
    "address": "Shadara,Lahore",
  },
  {
    "name": "Usman Haider",
    "userno": "03",
    "age": 87,
    "phone": "03138592841",
    "address": "Township, Lahore",
  },
  {
    "name": "Isra Bibi",
    "userno": "04",
    "age": 88,
    "phone": "03915960311",
    "address": "Gulshan e Ravi,Lahore",
  },
  {
    "name": "Waqar Yonus",
    "userno": "05",
    "age": 17,
    "phone": "03015467931",
    "address": "Model Town,Lahore",
  },
  {
    "name": "Syeda Zehra",
    "userno": "06",
    "age": 52,
    "phone": "0319857318",
    "address": "Iqbal Town,Lahore",
  },
  {
    "name": "Farwa Yonus",
    "userno": "07",
    "age": 46,
    "phone": "0300583293",
    "address": "Sanda,Lahore",
  }
];

class Tables extends React.Component {
  render() {
    return (
      <>
        <div className="content">
          <Row>
            <Col md="12">
              <Card>
                <CardHeader>
                  <CardTitle tag="h4">Registered Patients</CardTitle>
                </CardHeader>
                <CardBody>
                  <Table responsive>
                    <thead className="text-primary">
                      <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Contact Number</th>
                        <th className="text-right">Address</th>
                      </tr>
                    </thead>
                    <tbody>
                      {
                        patients.map((patient, index) => {
                          return (<tr key={index}>
                            <td>{patient.userno}</td>
                            <td>{patient.name}</td>
                            <td>{patient.age}</td>
                            <td>{patient.phone}</td>
                            <td className="text-right">{patient.address}</td>
                          </tr>);
                        })
                      }
                    </tbody>
                  </Table>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </>
    );
  }
}

export default Tables;
