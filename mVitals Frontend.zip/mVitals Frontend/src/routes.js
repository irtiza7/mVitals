
import Dashboard from "views/Dashboard.js";
import HistoricalData from "views/HistoricalData";
import UserPage from "views/User.js";
import AddUser from "views/AddUser.js";
import TreatmentDiagnosis from "views/TreatmentDiagnosis.js";
import SetAppointment from "views/SetAppointment";

var routes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "nc-icon nc-bank",
    component: Dashboard,
    layout: "/admin",
  },
  {
    path: "/user-page",
    name: "User Profile",
    icon: "nc-icon nc-single-02",
    component: UserPage,
    layout: "/admin",
  },
  {
    path: "/adduser",
    name: "Add New Patient",
    icon: "nc-icon nc-single-02",
    component: AddUser,
    layout: "/admin",
  },
  {
    path: "/TreatmentDiagnosis",
    name: "Treatment & Diagnosis",
    icon: "nc-icon nc-bulb-63",
    component: TreatmentDiagnosis,
    layout: "/admin",
  },
  {
    path: "/SetAppointment",
    name: "Set Appointment",
    icon: "nc-icon nc-bulb-63",
    component: SetAppointment,
    layout: "/admin",
  },
  {
    path: "/history",
    name: "Historical Data",
    icon: "nc-icon nc-chart-bar-32",
    component: HistoricalData,
    layout: "/admin",
  }
];
export default routes;
